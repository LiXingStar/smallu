// 弹幕显示
class BarrageDisplay {
    constructor() {
        // 编码大全
        this.data=[
            {id: 1, content: '前方弹幕来袭'},
            // {id: 2, content: '666!要开始了？'},
            // {id: 3, content: '小U加油！'},
            // {id: 4, content: '小U请开始你的表演！'},
            // {id: 5, content: '666 板凳已搬好'},
            // {id: 6, content: '66666 小U加油！'},
        ];
        this.render();
        $('.barrage-box .barrage-item').each((i, v) => {
            $(v).css({
                top: Math.ceil(Math.random() * 219),
                left: Math.ceil(Math.random() * -100)
            });
        });
        // 默认不显示弹幕
        this.toggle();
        // socket.on('server-push', this.onServerPush);
        $('.barrage').on('click', this.toggle)
    }

    onServerPush(data) {
        $(`<div class="barrage-item">${data}</div>`)
            .css({
                top: Math.ceil(Math.random() * 219),
                left: Math.ceil(Math.random() * -100)
            })
            .appendTo('.barrage-box');
    }

    toggle() {
        $('.barrage').toggleClass('active');
        $('.barrage-box,.barrage-sender').toggle();
    }

    render() {
        let el=`${this.data.map(v => `<div class="barrage-item">${v.content}</div>`).join('')} `;
        $(el).appendTo('.barrage-box');
    }
}

// 弹幕发送
// class BarrageSender {
//     constructor() {
//         this.render();
//         let input = $('#barrage-input');
//         $('#send').on('click', () => {
//             socket.emit('send-barrage', input.val());
//             input.val('');
//         })
//     }
//
//     render() {
//         let el = `<input type="text" id="barrage-input"><a id="send">send</a>`;
//         $(el).prependTo('.barrage-sender');
//     }
// }
// 播放暂停
class PlayPauseController {
    constructor() {
        let video=$('#video').get(0);
        video.addEventListener('play', () => {
            $('.play').removeClass('paused');
            $('.play-list').removeClass('active');
        });
        video.addEventListener('pause', () => {
            $('.play').addClass('paused');
            $('.play-list').addClass('active');
        });
        $('.play').on('click', this.togglePlay)
    }

    togglePlay() {
        let video=$('#video').get(0);
        if (video.paused) {
            video.play();
        } else {
            video.pause();
        }
    }
}

// 进度控制
class ProgressController {
    constructor() {
        let video=$('#video').get(0);
        video.addEventListener('canplay', () => {
            $('#total-time').html(this.format(video.duration));
        });
        video.addEventListener('timeupdate', () => {
            $('.current-bar').css('width', video.currentTime / video.duration * 100 + '%');
            $('#current-time').html(this.format(video.currentTime));
        });
        $('.progress').on('click', (e) => {
            video.currentTime=video.duration * e.offsetX / $('.progress').width();
        });
        $(".indicator").on('click', false);
    }

    format(second) {
        if (isNaN(second)) return '--:--';
        let m=Math.floor(second / 60);
        let s=Math.round(second % 60);
        m=m < 10 ? ('0' + m) : m;
        s=s < 10 ? ('0' + s) : s;
        return `${m}:${s}`;
    }
}

// 音量控制
class VolumeController {
    constructor() {
        let video=$("#video").get(0);
        $(".volume-controller").on('click', (e) => {
            video.volume=e.offsetX / $('.volume-controller').width();
            $('.v-current').width(video.volume * 100 + '%');
        });
    }
}

// 播放列表
// class PlayListController {
//     constructor() {
//         this.data = [
//             {id: 1, src: '/video/video1.mp4', pic: '/img/video1_1.png', title: 'video 1'},
//             {id: 2, src: '/video/video2.mp4', pic: '/img/video2_1.png', title: 'video 2'},
//             {id: 3, src: '/video/video3.mp4', pic: '/img/video3_1.png', title: 'video 3'},
//             {id: 4, src: '/video/video4.mp4', pic: '/img/video4_1.png', title: 'video 4'},
//             {id: 5, src: '/video/video5.mp4', pic: '/img/video5_1.png', title: 'video 5'}
//         ];
//         this.render();
//         $("#ul").on('click', 'li', (e) => {
//             $("#video").get(0).src = this.data[$(e.currentTarget).index()].src;
//         })
//     }
//
//     render() {
//         let el = this.data.map(v => `
//         <li class="list-item">
//             <div class="pic">
//                 <img src="${v.pic}" alt="">
//             </div>
//             <div class="content">
//                 <h3>${v.title}</h3>
//             </div>
//         </li>
//         `).join('');
//         $(el).appendTo('#ul');
//     }
// }
// 清晰度切换
class ClarityController {
    constructor() {
        $(".setting").on('click', (e) => {
            e.stopPropagation();
            $(e.currentTarget).toggleClass('active');
            $('#menu').toggle();
        });
        $('#menu li').on('click', (e) => {
            e.stopPropagation();
            $('#menu li').removeClass('active');
            $(e.currentTarget).addClass('active');
            let video=$('#video').get(0);
            let current=video.currentTime;
            let type=$(e.currentTarget).html();
            var i=/video(\d)/g.exec(video.src)[0];
            if (type === '320p') {
                video.src='/video/' + i + '_320.mp4';
            } else if (type === '480p') {
                video.src='/video/' + i + '_480.mp4';
            } else if (type === '720p') {
                video.src='/video/' + i + '.mp4';
            }
            video.currentTime=current;
            video.play();
        });
        $(document).on('click', () => {
            $('#menu').hide();
            $('.setting').removeClass('active');
        })
    }
}

// 全屏控制
class FullScreenController {
    constructor() {
        $('.full-screen').on('click', () => {
            $('#video').get(0).webkitRequestFullscreen();
        });
    }
}

class Video {
    constructor() {
        new BarrageDisplay();
        new PlayPauseController();
        new ProgressController();
        new VolumeController();
        new ClarityController();
        new FullScreenController();
    }
}

new Video();