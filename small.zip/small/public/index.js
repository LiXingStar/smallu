//语音识别、合成
class uekSpeechSynthesis{
    //constructor
    constructor(){
        this.sync = window.speechSynthesis;
        this.utterThis=[];

        // let SpeechRecognition = SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;
        // this.recognition=new SpeechRecognition();
        // this.recognition.lang = 'zh-cn';
    }
    //Getter
    /**
     * 可以支持的服务
     */
    getVoices(){
        return this.sync.getVoices();
    }
    //Setter
    setText(str){
        this.utterThis.push(new window.SpeechSynthesisUtterance(str));
    }

    /**
     * 讲话
     * str 合成的文本
     */
    speak(str){
        this.utterThis.push(new window.SpeechSynthesisUtterance(str));
        this.sync.speak(this.utterThis.shift());
    }
    /**
     * 语音识别
     */
    // dist(cbk){
    //     this.recognition.start();
    //     this.recognition.onspeechend = ()=>{ recognition.stop(); }
    //     this.recognition.onresult = function(event) {
    //         cbk(event.results[0][0].transcript);
    //       }
    // }

}
const synthesis = new uekSpeechSynthesis();
//打字效果
let writeWord=function(str){
    synthesis.speak(str);
    let i = 0;
    function typing(){
        let divTyping = document.querySelector('#u>.u-msg>.gj-text');
        if (i <= str.length) {
            divTyping.innerHTML = str.slice(0, i++) + '_';
            setTimeout(typing, 250);//递归调用
        }
        else{
            divTyping.innerHTML = str;//结束打字,移除 _ 光标
        }
    }
    typing();
}

let socket = io('/');
socket.on('server-push', (order) =>{
    order=JSON.parse(order);
    window[order.ext](order);
});

//加载图片
/*function loadImaage(){
    //<div class="swiper-slide" style="background-image:url('/ppt/lzp1/1.jpg')" > </div>
    let wrap_box = document.querySelector('.swiper-wrapper');
    for(let i=0;i<){}
    let zWrap_box=document.createElement('div');

    // zWrap_box
    wrap_box.appendChild()
}*/



let Shidden=function(){
    window.hideU();
    window.hidePpt();
    window.stopPlay();
    window.hidePpt();
}

// 视频播放和隐藏
window.startPlay = () => {
    Shidden();
    $('.video-box').addClass('show');
    $('#video').get(0).play()
};
window.stopPlay = () => $('.video-box').removeClass('show');

// ppt上下翻页
window.next = mySwiper.slideNext.bind(mySwiper);
window.prev = mySwiper.slidePrev.bind(mySwiper);

// ppt隐藏和显示
window.showPpt = () => {Shidden();$(".ppt").addClass('show')};
window.hidePpt = () => $(".ppt").removeClass('show');

// U隐藏和显示
window.showU = () => {Shidden();$("#u").addClass('show')};
window.hideU = () => $("#u").removeClass('show');
//请开始说话，您好，我是小U，我是一名智能机器人，接下来我将为大家主持全栈组的年终述职。请大家以热烈的掌声欢迎全栈组的同事们。接下来，首先是我们的极客新人--刘智攀老师为大家带来他的年终述职。
window.uIntro = (obj)=>{$("#u").addClass('show');writeWord(obj.info);};




