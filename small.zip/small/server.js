let path = require('path');

let express = require('express');
let app = express();

let server = require('http').Server(app);
let io = require('socket.io')(server);

app.use(express.static('./public'));

app.get('/',(req,res)=>{
    res.sendFile(path.resolve('./view/index.html'));
});

app.get('/admin',(req,res)=>{
    res.sendFile(path.resolve('./view/admin.html'))
});

io.on('connect',(socket)=>{
    socket.on('admin-order',(data)=>{
        socket.broadcast.emit('server-push',data);
    })
});

server.listen(8080);
